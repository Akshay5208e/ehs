import img000001 from '../Image/Fire equipment/F0001.jpg'
import img000002 from '../Image/Fire equipment/F0002.jpg'
import img000003 from '../Image/Fire equipment/F0003.jpg'
import img000004 from '../Image/Fire equipment/F0004.jpg'
import img000005 from '../Image/Fire equipment/F0005.jpg'

import img00101 from '../Image/Mandatory/M0001.jpg'
import img00102 from '../Image/Mandatory/M0002.jpg'
import img00103 from '../Image/Mandatory/M0003.jpg'
import img00104 from '../Image/Mandatory/M0004.jpg'
import img00105 from '../Image/Mandatory/M0005.jpg'

import img01010 from '../Image/Prohibitiob/P0001.jpg'
import img02020 from '../Image/Prohibitiob/P0002.jpg'
import img03030 from '../Image/Prohibitiob/P0003.jpg'
import img04040 from '../Image/Prohibitiob/P0004.jpg'
import img05050 from '../Image/Prohibitiob/P0005.jpg'

import img01001 from '../Image/Warning/W0001.jpg'
import img01002 from '../Image/Warning/W0002.jpg'
import img01003 from '../Image/Warning/W0003.jpg'
import img01004 from '../Image/Warning/W0004.jpg'
import img01005 from '../Image/Warning/W0005.jpg'






const pictogramsAllData=[
    {
        "id":"000001",
        "img": img000001
    },
    {
        "id":"000002",
        "img": img000002
    },
    {
        "id":"000003",
        "img": img000003
    },
    {
        "id":"000004",
        "img": img000004
    },
    {
        "id":"000005",
        "img": img000005
    },
    {
        "id":"00101",
        "img": img00101
    },
    {
        "id":"00202",
        "img": img00102
    },
    {
        "id":"00303",
        "img": img00103
    },
    {
        "id":"00404",
        "img": img00104
    },
    {
        "id":"00505",
        "img": img00105
    },
    {
        "id":"01010",
        "img": img01010
    },
    {
        "id":"02020",
        "img": img02020
    },
    {
        "id":"03030",
        "img": img03030
    },
    {
        "id":"04040",
        "img": img04040
    },
    {
        "id":"05050",
        "img": img05050
    },
    {
        "id":"01001",
        "img": img01001
    },
    {
        "id":"02002",
        "img": img01002
    },
    {
        "id":"03003",
        "img": img01003
    },
    {
        "id":"04004",
        "img": img01004
    },
    {
        "id":"05005",
        "img": img01005
    }
    
]

export default pictogramsAllData;