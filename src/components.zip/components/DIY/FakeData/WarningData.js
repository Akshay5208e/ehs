import img1 from '../Image/Warning/W0001.jpg'
import img2 from '../Image/Warning/W0002.jpg'
import img3 from '../Image/Warning/W0003.jpg'
import img4 from '../Image/Warning/W0004.jpg'
import img5 from '../Image/Warning/W0005.jpg'


const warning=[
    {
        "id":"01001",
        "img": img1
    },
    {
        "id":"02002",
        "img": img2
    },
    {
        "id":"03003",
        "img": img3
    },
    {
        "id":"04004",
        "img": img4
    },
    {
        "id":"05005",
        "img": img5
    }
    
]

export default warning;