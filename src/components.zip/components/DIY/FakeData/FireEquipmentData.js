import img1 from '../Image/Fire equipment/F0001.jpg'
import img2 from '../Image/Fire equipment/F0002.jpg'
import img3 from '../Image/Fire equipment/F0003.jpg'
import img4 from '../Image/Fire equipment/F0004.jpg'
import img5 from '../Image/Fire equipment/F0005.jpg'




const fireEquipment=[
    {
        "id":"000001",
        "img": img1
    },
    {
        "id":"000002",
        "img": img2
    },
    {
        "id":"000003",
        "img": img3
    },
    {
        "id":"000004",
        "img": img4
    },
    {
        "id":"000005",
        "img": img5
    }
    
]

export default fireEquipment;