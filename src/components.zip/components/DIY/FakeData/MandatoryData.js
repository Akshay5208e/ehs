import img1 from '../Image/Mandatory/M0001.jpg'
import img2 from '../Image/Mandatory/M0002.jpg'
import img3 from '../Image/Mandatory/M0003.jpg'
import img4 from '../Image/Mandatory/M0004.jpg'
import img5 from '../Image/Mandatory/M0005.jpg'




const mandatory=[
    {
        "id":"00101",
        "img": img1
    },
    {
        "id":"00202",
        "img": img2
    },
    {
        "id":"00303",
        "img": img3
    },
    {
        "id":"00404",
        "img": img4
    },
    {
        "id":"00505",
        "img": img5
    }
    
]

export default mandatory;