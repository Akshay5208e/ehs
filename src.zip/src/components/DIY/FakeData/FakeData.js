import img1 from '../Image/C001A_C_10x7_01.jpeg'
import img2 from '../Image/D001A_C_10x7_01.jpeg'
import img3 from '../Image/N001A_C_10x7_01.jpeg'
import img4 from '../Image/N001A_C_10x7_01_italic.jpeg'
import img5 from '../Image/W001A_C_10x7_01.jpeg'
import img6 from '../Image/Caution_7x10_01.jpeg'
import img7 from '../Image/Danger_7x10_02.jpeg'
import img8 from '../Image/Notice_7x10_01.jpeg'
import img9 from '../Image/Notice_7x10_Italic_01.jpeg'
import img10 from '../Image/Warning_7x10_01.jpeg'


const image = [
    {
      "id": "01",
      "item": "01",
      "img": img1,
    },
    {
      "id": "02",
      "item": "01",
      "img": img2,
    },
    {
      "id": "03",
      "item": "01",
      "img": img3,
    },
    {
      "id": "04",
      "item": "01",
      "img": img4,
    },
    {
      "id": "05",
      "item": "01",
      "img": img5,
    },
    {
      "id": "06",
      "item": "02",
      "img": img6,
    },
    {
      "id": "07",
      "item": "02",
      "img": img7,
    },
    {
      "id": "08",
      "item": "02",
      "img": img8,
    },
    {
      "id": "09",
      "item": "02",
      "img": img9,
    },
    {
      "id": "10",
      "item": "02",
      "img": img10,
    },
  ];
  

export default image;