import img1 from '../Image/Prohibitiob/P0001.jpg'
import img2 from '../Image/Prohibitiob/P0002.jpg'
import img3 from '../Image/Prohibitiob/P0003.jpg'
import img4 from '../Image/Prohibitiob/P0004.jpg'
import img5 from '../Image/Prohibitiob/P0005.jpg'


const prohibitiob=[
    {
        "id":"01010",
        "img": img1
    },
    {
        "id":"02020",
        "img": img2
    },
    {
        "id":"03030",
        "img": img3
    },
    {
        "id":"04040",
        "img": img4
    },
    {
        "id":"05050",
        "img": img5
    }
    
]

export default prohibitiob;