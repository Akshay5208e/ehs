import React,{useState,useEffect} from 'react'
import {API} from "../../backend";
import Axios from "axios";
import {Link} from "react-router-dom"



const Card = (props) => {
    return(
        <div className="br-22 bestsellerCard d-flex flex-column justify-content-start">
            <img src={props.imgUrl} className="br-22 bestsellerImg"  />
            <p className="bestsellerText  mb-0 px-2">{props.title}</p>
        </div>
    )
};


function FloorGraphicSearch({key}) {
    const [allFloorGraphics, setAllFloorGraphics] = useState([]);
    const [allItems, setAllItems] = useState([])


    useEffect(()=>{

     
    
        Axios.get(`${API}posters/getPosterByCatSubCat`, {params: {category_slug: "floor-graphics"}}).then((res)=>{
          setAllFloorGraphics(res.data.data.postersExists);
         console.log(res);
        }).catch((err)=> {
          console.log(err);
        });
     
      },[]);

    return (
        <div>
                {
                        allFloorGraphics.length>0 &&  allFloorGraphics.map((val,i)=>{
                            return(
                                <Link  to="">  <Card title={val.name ? val.name : "-"} imgUrl={val.imgUrl.length>0 ? val.imgUrl[0] : ""} /></Link>
                             )
                        })
                    }
            
        </div>
    )
}

export default FloorGraphicSearch
