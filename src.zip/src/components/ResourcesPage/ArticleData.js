const article = [
    {
        key:"1",
        name: "chemical",
        title: "Chemical Safety",
        thumbnail: require("../../images/BeSafe.png"),
        content:[
            "Eiusmod nostrud elit ut consequat qui proident pariatur. Incididunt ipsum mollit enim anim mollit eu aliqua ut mollit ipsum ut nostrud sint ad. Pariatur nulla amet aute incididunt commodo ipsum velit consequat amet quis laborum reprehenderit velit. Deserunt id esse ea deserunt duis mollit fugiat cupidatat laboris consequat nostrud proident veniam incididunt. Aliquip ullamco Lorem mollit sunt amet aliquip. Cupidatat voluptate aute reprehenderit amet esse ullamco nostrud.",
            "Cillum labore do amet veniam voluptate voluptate elit. Ut elit ex officia proident eu cillum dolore in cupidatat consectetur excepteur labore aute. Cillum aliquip reprehenderit reprehenderit ullamco magna. Consequat officia sunt qui magna culpa. Magna cupidatat cupidatat duis dolore ea nisi.",
            "Cillum irure qui mollit eu aliqua non do adipisicing. Quis reprehenderit aliquip velit proident. Veniam do et nostrud consectetur est velit Lorem. Lorem exercitation officia laborum veniam.",
        ],
    },
    {
        key:"2",
        name: "fire",
        title: "Fire Safety",
        thumbnail: require("../../images/BeSafe.png"),
        content:[
            "Eiusmod nostrud elit ut consequat qui proident pariatur. Incididunt ipsum mollit enim anim mollit eu aliqua ut mollit ipsum ut nostrud sint ad. Pariatur nulla amet aute incididunt commodo ipsum velit consequat amet quis laborum reprehenderit velit. Deserunt id esse ea deserunt duis mollit fugiat cupidatat laboris consequat nostrud proident veniam incididunt. Aliquip ullamco Lorem mollit sunt amet aliquip. Cupidatat voluptate aute reprehenderit amet esse ullamco nostrud.",
            "Cillum labore do amet veniam voluptate voluptate elit. Ut elit ex officia proident eu cillum dolore in cupidatat consectetur excepteur labore aute. Cillum aliquip reprehenderit reprehenderit ullamco magna. Consequat officia sunt qui magna culpa. Magna cupidatat cupidatat duis dolore ea nisi.",
            "Cillum irure qui mollit eu aliqua non do adipisicing. Quis reprehenderit aliquip velit proident. Veniam do et nostrud consectetur est velit Lorem. Lorem exercitation officia laborum veniam.",
        ],
    },
    {
        key:"3",
        name: "chemical",
        title: "Chemical Safety",
        thumbnail: require("../../images/BeSafe.png"),
        content:[
            "Eiusmod nostrud elit ut consequat qui proident pariatur. Incididunt ipsum mollit enim anim mollit eu aliqua ut mollit ipsum ut nostrud sint ad. Pariatur nulla amet aute incididunt commodo ipsum velit consequat amet quis laborum reprehenderit velit. Deserunt id esse ea deserunt duis mollit fugiat cupidatat laboris consequat nostrud proident veniam incididunt. Aliquip ullamco Lorem mollit sunt amet aliquip. Cupidatat voluptate aute reprehenderit amet esse ullamco nostrud.",
            "Cillum labore do amet veniam voluptate voluptate elit. Ut elit ex officia proident eu cillum dolore in cupidatat consectetur excepteur labore aute. Cillum aliquip reprehenderit reprehenderit ullamco magna. Consequat officia sunt qui magna culpa. Magna cupidatat cupidatat duis dolore ea nisi.",
            "Cillum irure qui mollit eu aliqua non do adipisicing. Quis reprehenderit aliquip velit proident. Veniam do et nostrud consectetur est velit Lorem. Lorem exercitation officia laborum veniam.",
        ],
    },
];

export default article;