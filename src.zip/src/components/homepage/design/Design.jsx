/*jshint esversion: 6 */
import React from "react";
import "./Design.css";
import banner from "../../../images/banner.jpg";

const Design = () => {
  return (
    <div>
    <div className="design ">  </div>
    <div className="tagline ">
      <p>The Best Environment, Health and Safety Prints for your Workplace</p>
    </div>
    </div>
  );
};

export default Design;
