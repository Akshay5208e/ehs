import React from "react";


const ComingSoon = () => {
    return(
        <div>
            Coming Soon
        </div>
    );
};


export default ComingSoon;