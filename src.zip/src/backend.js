// export const API = process.env.REACT_APP_BACKEND;
// export const API = "http://localhost:8080/";
// export const API = "http://ec2-13-232-192-232.ap-south-1.compute.amazonaws.com:8000/";
// export const API = "http://ec2-13-127-141-252.ap-south-1.compute.amazonaws.com:8000/";
export const API = "http://3.110.29.235:8000/";