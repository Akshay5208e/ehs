import React from 'react'; 
const couponInfo = React.createContext([{}, () => {}]); 
export default couponInfo;