import React from 'react'; 
const cartContext = React.createContext([{}, () => {}]); 
export default cartContext;