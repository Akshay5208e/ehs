import firebase from 'firebase/app'
import "firebase/auth"


 const firebaseConfig = {

  apiKey: "AIzaSyCrmUgoEKpL0nqEw4VnpG871gT30V9fEbE",
  authDomain: "ehs-firebase-auth.firebaseapp.com",
  projectId: "ehs-firebase-auth",
  storageBucket: "ehs-firebase-auth.appspot.com",
  messagingSenderId: "168890505130",
  appId: "1:168890505130:web:67874ad07f3af1fef33dd3",
  measurementId: "G-TWVQNC3MSG"
}


export const app= firebase.initializeApp(firebaseConfig)

const auth = firebase.auth();
const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
const facebookAuthProvider = new firebase.auth.FacebookAuthProvider(); 

export {auth, googleAuthProvider, facebookAuthProvider}