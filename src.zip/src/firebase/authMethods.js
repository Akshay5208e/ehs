// import firebase from './firebaseConfig'
// export const facebookProvider=  new firebase.auth.FacebookAuthProvider();
// export const googleProvider=  new firebase.auth.GoogleAuthProvider();